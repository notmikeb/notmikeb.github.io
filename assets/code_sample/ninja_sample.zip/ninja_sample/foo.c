#include <stdio.h>

int germ();

int main(){
printf("ninja ~ %d\n", germ());
printf("ninja ~ %d\n", germ());
printf("ninja ~ %d\n", germ());
return 1;
}