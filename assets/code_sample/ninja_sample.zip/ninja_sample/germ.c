#include <stdio.h>


static int g_germ = 0;
int germ()
{
return g_germ++;
}